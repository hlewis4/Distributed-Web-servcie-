package edu.umbc.dos.Server2.lb;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.beans.factory.DisposableBean;
import org.springframework.stereotype.Component;

@Component
public class StartupManager implements DisposableBean {

	@PostConstruct
	public void init() {
		System.out.println("Starting Load Balancer");
		String data = "<Envelope xmlns=\"http://schemas.xmlsoap.org/soap/envelope/\"><Body><Alive xmlns=\"http://lb.WebService.dos.umbc.edu/\"><ipAddress xmlns=\"\">130.85.251.167</ipAddress><port xmlns=\"\">8082</port><serviceName xmlns=\"\">[ADD,MUL]</serviceName></Alive></Body></Envelope>";
		UrlConnection con = new UrlConnection("http://130.85.252.23:8081/server", data);
		Thread t = new Thread(con);
		t.start();
	}
	
	@PreDestroy
	@Override
	public void destroy() throws Exception {
		String data = "<Envelope xmlns=\"http://schemas.xmlsoap.org/soap/envelope/\"><Body><Dead xmlns=\"http://lb.WebService.dos.umbc.edu/\"><ipAddress xmlns=\"\">130.85.251.167</ipAddress><port xmlns=\"\">8082</port></Dead></Body></Envelope>";
		UrlConnection con = new UrlConnection("http://130.85.252.23:8081/server", data);
		Thread t = new Thread(con);
		t.start();
		t.join();
	}
	
}
